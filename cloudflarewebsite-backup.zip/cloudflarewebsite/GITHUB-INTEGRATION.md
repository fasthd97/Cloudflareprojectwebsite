# GitHub Integration Setup

This document explains how to add GitHub integration to your Cloudflare Pages project for automatic deployments.

## Current Status
- ✅ Infrastructure managed by Terraform
- ✅ Manual deployments via `wrangler pages deploy`
- ❌ GitHub integration (to be added later)

## Adding GitHub Integration

### Step 1: Update Terraform Configuration

Uncomment the GitHub source block in `terraform/main.tf`:

```hcl
# Source configuration (GitHub integration)
source {
  type = "github"
  config {
    owner                         = var.github_username
    repo_name                     = var.github_repo_name
    production_branch             = "main"
    pr_comments_enabled           = true
    deployments_enabled           = true
    production_deployment_enabled = true
  }
}
```

### Step 2: Update Variables

Set your GitHub details in `terraform/terraform.tfvars`:

```hcl
github_username = "your-actual-username"
github_repo_name = "cloudflarewebsite"
```

### Step 3: Connect GitHub Account

1. Go to Cloudflare Dashboard → Pages → Settings
2. Connect your GitHub account
3. Grant repository access permissions

### Step 4: Apply Changes

```bash
cd terraform
terraform apply
```

## Benefits of GitHub Integration

- **Automatic Deployments**: Push to main branch = automatic deployment
- **Preview Deployments**: Pull requests get preview URLs
- **Build Logs**: See deployment status in GitHub
- **Rollback**: Easy rollback to previous commits

## Manual Deployment (Current Method)

```bash
# Deploy static site
wrangler pages deploy public --project-name resumecloudflare

# Deploy worker
wrangler deploy
```

## Troubleshooting

If GitHub integration fails:
1. Check repository permissions
2. Verify GitHub app installation
3. Ensure branch names match
4. Contact Cloudflare support if needed

## Security Notes

- Only grant minimum required permissions
- Use branch protection rules
- Review deployment logs regularly
- Keep secrets in Cloudflare environment variables